var store = [{
        "title": "이미지 추가",
        "excerpt":"깃허브 블로그 이미지 추가 연습      https://www.youtube.com/watch?v=1UEOWcKcVdk&amp;list=PLIMb_GuNnFwfQBZQwD-vCZENL5YLDZekr&amp;index=2       ","categories": [],
        "tags": [],
        "url": "/2nd/",
        "teaser": null
      },{
        "title": "첫 포스트 입니다.",
        "excerpt":"오늘 처음 블로그를 만들었어요 앞으로 열심히 해보겠습니다. 오도근 멘토님 깃허브 블로그의 존재를 알려주셔서 감사합니다. 깃허브 블로그를 하는 이유: 기존 블로그 장점: 바로 이용 가능 단점: 커스텀 하기 불편 직접 만들어 보기 장점: 원하는데로 가능 단점: 학습할게 너무 많은, 호스팅 비용 잠정적으론 시도 해볼 예정 깃허브 페이지 만들기 장점: 비교적 선택의...","categories": [],
        "tags": [],
        "url": "/first/",
        "teaser": null
      },{
        "title": "실시간으로 반영하게 하기",
        "excerpt":"실시간으로 반영하게 하기      https://www.youtube.com/watch?v=0TeHUqSAb6Q&amp;list=PLIMb_GuNnFwfQBZQwD-vCZENL5YLDZekr&amp;index=3     실시간으로 반영이 되난 감?   아니가?   ","categories": [],
        "tags": [],
        "url": "/3rd/",
        "teaser": null
      }]
